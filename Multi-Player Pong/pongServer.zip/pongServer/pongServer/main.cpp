#include <iostream>
#include "pongServer.h"


int main() {
    pongServer s = pongServer();
    s.start();
    return 0;
}